from django.shortcuts import render

# Create your views here.
'''
views.py : MTV패턴 중 실직적인 데이터추출, 연산, HTML 전달의
기능이 구현되는 파일
view의 기능을 구현할 때는 클래스/함수를 정의해 사용할 수 있음.
함수를 정의해 view의 기능을 구현할때는 첫번째매개변수를 필수적으로 있어야 한다. 

request : 웹 클라이언트의 요청정보가 저장된 매개변수
request안에는 <form>를 바탕으로 사용자가 입력한 값이나 
로그인 정보, 요청방식 등을 변수형태로 저장하고 있다.
'''
#테스트용 뷰함수
def test(request):
    #render(request, HTML파일경로, 사전형데이터) 
    #해당요청을 보낸 웹클라이언트에게 전송할 HTML 파일을 
    #사전형데이터로 편집한 뒤 전송하는 함수
    #뷰함수는 반드시 HTML파일이나 다른사이트주소, 파일데이터를 
    #return 시켜야함. 
    return render(request,"test.html",{})

#뷰함수가 템플릿이 HTML을 변경할 수 있도록 변수값 전달 
    
def test_value(request):
    #render함수의 인자값으로 사용할 사전형 데이터 생성 
    dict = {'a':'홍길동님','b':[1,2,3,4,5]}
    #dict['a']
    return render(request,"test_value.html",dict)

def test_input(request,number):
    print(number)
    return render(request,"test_input.html",{'a':number})

#Question 모델 클래스 import 
from vote.models import Question
    
#메인화면 - 데이터 베이스에 저장된 Question객체를 바탕으로 HTML을 전달

def main(request):
    #데이터베이스에 저장된 모든 Question 객체를 추출
    '''
    Question.object : 데이터 베이스에 저장된 Question객체들을
    접근할때 사용하는 변수 
    객체를 접근할때는 4가지 함수로 접근할 수 있음.
    all():데이터 베이스에 저장된 모든 객체를 리스트형태로 추출
    get(조건):데이터 베이스에 저장된 객체 중 조건을 만족하는 객체 1개를 추출
    filter(조건) : 데이터베이스에 저장된 객체 중 조건을 만족하는 모든 객체를 리스트형태로 추출
    exclude(조건) : 데이터베이스에 저장된 객체 중 조건을 만족하지 않는 객체를 리스트형태로 추출 
    '''
    q = Question.objects.all()
    print(q)
    #추출된 Question 객체를 HTML 편집에 사용할 수 있도록 전달
    return render(request,"vote/main.html",{'q':q})



