from django.db import models

# Create your models here.
'''
models.py : 모델클래스를 정의할 때 사용하는 파일
모델 클래스 개발 및 반영 순서
1) 모델클래스 정의시, 미리 import된 models 파일에 있는 
Model 클래스 상속. 해당 클래스에 저장할 변수들을 클래스 변수로 선언 

2) 모델클래스를 migration파일로 변환 - manage.py에게 명령

3) 애플리케이션별 migration파일을 데이터베이스에 반영 - manage.py에게 명령

4) admin.py에 정의된 모델클래스를 등록 

모델 클래스의 클래스 변수는 해당 클래스가 저장할 수 있는 데이터를 의미한다. 
클래스 변수에 저장할 데이터 형식을 models.xxxxfield의 객체를 저장해 
지정할 수 있다.  


'''

#설문항목을 저장하는 모델클래스
class Question(models.Model):
    #제목
    #100글자로 제한된 문자열을 저장할 수 있는 공간을 생성
    #CharField : 글자수 제한이 있는 저장공간을 생성할때 사용하는 클래스
    #CharField객체 생성시 max_length(최대글자제한) 매개변수에 정수 값 입력
    #정수값을 필수적으로 입력해야함 
    title = models.CharField(max_length=100)
    #생성일 - pub_date변수 생성
    #DateField - 년월일 데이터를 저장할 수 있는 공간
    #DateTimeField = 년월일+시분초 데이터를 저장할 수 있는 공간
    #옵션) auto_now_add 매개변수 : True값 설정시, 서버의 시간을
    #데이터베이스에 저장할 때 자동으로 입력해준다. 
    pub_date = models.DateTimeField(auto_now_add=True)
    
    

#설문항목에 연결된 답변항목을 저장하는 모델클래스

